# DDOS-TOOLS-NEW-UPDATE
DDOS TOOLS FOR FREE

[Layer 7]

 - cfb   | Bypass CF attack

 - pxcfb | Bypass CF attack with proxy

 - cfpro | Bypass CF UAM(Under Attack Mode), CAPTCHA, BFM(Bot Fight Mode) etc.. (request)

 - cfsoc | Bypass CF UAM(Under Attack Mode), CAPTCHA, BFM(Bot Fight Mode) etc.. (socket)

 - raw   | Request Attack

 - post  | Post Request Attack

 - head  | Head Request Attack

 - soc   | Socket Attack

 - pxraw | Proxy Request Attack

 - pxsoc | Proxy Socket Attack

 

  [Layer 4]

  -udp | simple udp flood

  -tcp | simple tcp flood

  

  [Tools]

 - Dns        | Classic DNS Lookup

 - Geoip      | Geo IP Address Lookup

 - Subnet     | Subnet IP Address Lookup
